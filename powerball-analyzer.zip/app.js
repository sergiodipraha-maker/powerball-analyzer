let historicalDraws = [];

const elements = {
  strategy: document.getElementById("strategy"),
  poolSize: document.getElementById("poolSize"),
  poolSizeValue: document.getElementById("poolSizeValue"),
  avoidConsecutive: document.getElementById("avoidConsecutive"),
  balanceOddEven: document.getElementById("balanceOddEven"),
  generateButton: document.getElementById("generateButton"),
  copyButton: document.getElementById("copyButton"),
  lines: document.getElementById("lines"),
  coverageSummary: document.getElementById("coverageSummary"),
  generatedAt: document.getElementById("generatedAt"),
  dataStatus: document.getElementById("dataStatus"),
  simulations: document.getElementById("simulations"),
  backtestButton: document.getElementById("backtestButton"),
  backtestOutput: document.getElementById("backtestOutput")
};

async function loadData() {
  try {
    const response = await fetch("data/powerball-results.json", { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    historicalDraws = Array.isArray(payload.draws) ? payload.draws : [];
    elements.dataStatus.textContent = historicalDraws.length
      ? `${historicalDraws.length} historical draws loaded.`
      : "Historical file is ready but currently empty; generator uses neutral coverage mode.";
  } catch (error) {
    historicalDraws = [];
    elements.dataStatus.textContent = "Historical data unavailable; generator uses neutral coverage mode.";
  }
}

function renderLines(lines) {
  elements.lines.innerHTML = lines.map((line, index) => `
    <div class="line-row">
      <span class="line-index">${String(index + 1).padStart(2, "0")}</span>
      <div class="number-list">
        ${line.main.map(n => `<span class="ball">${n}</span>`).join("")}
      </div>
      <span class="ball power">${line.powerball}</span>
    </div>
  `).join("");

  const summary = PowerballCoverageWheel.summarize(lines.map(x => x.main));
  const uniquePB = new Set(lines.map(x => x.powerball)).size;

  elements.coverageSummary.innerHTML = `
    <div class="metric"><strong>${summary.uniqueMain}</strong><span>unique main numbers</span></div>
    <div class="metric"><strong>${uniquePB}</strong><span>unique Powerballs</span></div>
    <div class="metric"><strong>${summary.pairRepeats}</strong><span>repeated pairs</span></div>
    <div class="metric"><strong>${summary.oddPercent}%</strong><span>odd-number share</span></div>
  `;

  elements.generatedAt.textContent = new Date().toLocaleString();
  window.currentLines = lines;
}

function generate() {
  const lines = PowerballLineGenerator.generate(historicalDraws, {
    strategy: elements.strategy.value,
    poolSize: Number(elements.poolSize.value),
    lineCount: 7,
    avoidConsecutive: elements.avoidConsecutive.checked,
    balanceOddEven: elements.balanceOddEven.checked
  });
  renderLines(lines);
}

async function copyLines() {
  if (!window.currentLines) return;
  const text = window.currentLines.map((line, i) =>
    `${i + 1}. ${line.main.join(" - ")} | PB ${line.powerball}`
  ).join("\n");

  try {
    await navigator.clipboard.writeText(text);
    const previous = elements.copyButton.textContent;
    elements.copyButton.textContent = "Copied ✓";
    setTimeout(() => elements.copyButton.textContent = previous, 1300);
  } catch {
    alert(text);
  }
}

function percent(value) {
  return `${(value * 100).toFixed(2)}%`;
}

function delta(engine, baseline) {
  if (!baseline) return "—";
  const d = ((engine - baseline) / Math.abs(baseline || 1)) * 100;
  const cls = d >= 0 ? "positive" : "negative";
  return `<span class="${cls}">${d >= 0 ? "+" : ""}${d.toFixed(2)}%</span>`;
}

function runBacktest() {
  try {
    elements.backtestButton.disabled = true;
    elements.backtestButton.textContent = "Running…";
    const result = PowerballRandomBaseline.backtest(
      historicalDraws,
      Number(elements.simulations.value),
      30
    );

    const { engine, baseline } = result;
    elements.backtestOutput.innerHTML = `
      <p class="small">
        Walk-forward draws: <strong>${engine.draws}</strong> ·
        Random simulations: <strong>${result.simulations}</strong>
      </p>
      <table class="result-table">
        <thead>
          <tr><th>Metric</th><th>Engine</th><th>Random</th><th>Difference</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>Average weighted score</td>
            <td>${engine.avgWeighted.toFixed(3)}</td>
            <td>${baseline.avgWeighted.toFixed(3)}</td>
            <td>${delta(engine.avgWeighted, baseline.avgWeighted)}</td>
          </tr>
          <tr>
            <td>Average best main match</td>
            <td>${engine.avgBestMain.toFixed(3)}</td>
            <td>${baseline.avgBestMain.toFixed(3)}</td>
            <td>${delta(engine.avgBestMain, baseline.avgBestMain)}</td>
          </tr>
          <tr>
            <td>Any Powerball match</td>
            <td>${percent(engine.powerballRate)}</td>
            <td>${percent(baseline.powerballRate)}</td>
            <td>${delta(engine.powerballRate, baseline.powerballRate)}</td>
          </tr>
          <tr>
            <td>At least one 3+ main match</td>
            <td>${percent(engine.match3Rate)}</td>
            <td>${percent(baseline.match3Rate)}</td>
            <td>${delta(engine.match3Rate, baseline.match3Rate)}</td>
          </tr>
        </tbody>
      </table>
      <p class="small">
        A positive result is not proof of future advantage. Lottery draws remain random,
        and small samples can produce misleading differences.
      </p>
    `;
  } catch (error) {
    elements.backtestOutput.innerHTML = `<p>${error.message}</p>`;
  } finally {
    elements.backtestButton.disabled = false;
    elements.backtestButton.textContent = "Run honest backtest";
  }
}

elements.poolSize.addEventListener("input", () => {
  elements.poolSizeValue.textContent = elements.poolSize.value;
});
elements.generateButton.addEventListener("click", generate);
elements.copyButton.addEventListener("click", copyLines);
elements.backtestButton.addEventListener("click", runBacktest);

loadData().finally(generate);
