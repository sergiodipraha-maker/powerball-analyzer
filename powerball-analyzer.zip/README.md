# Powerball Analyzer

An independent Powerball analysis project for the UK game format:

- 5 main numbers from 1–69
- 1 Powerball from 1–26
- 7-line structured generator
- coverage wheel
- walk-forward backtest against a random baseline
- GitHub Pages deployment
- scheduled GitHub Actions workflow

## Important

This project does **not** predict winning numbers and does not guarantee a prize.
Every valid line has the same jackpot probability. The engine only structures how
multiple lines overlap and provides transparent historical comparison.

## Local use

Open the project through a local web server:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Historical results

Results are stored in:

```text
data/powerball-results.json
```

Expected draw format:

```json
{
  "date": "2026-07-22",
  "main": [1, 2, 3, 4, 5],
  "powerball": 6
}
```

The starter database is intentionally empty until an official or authorised source
is configured.

## Automatic update

The workflow `.github/workflows/update-results.yml` reads a repository secret named:

```text
POWERBALL_RESULTS_URL
```

The URL must return:

```json
{
  "draws": [
    {
      "date": "2026-07-22",
      "main": [1, 2, 3, 4, 5],
      "powerball": 6
    }
  ]
}
```

The updater validates and merges draws by date.

## GitHub Pages

After uploading the files:

1. Open repository **Settings**
2. Open **Pages**
3. Under **Build and deployment**, choose **GitHub Actions**
4. Open the **Actions** tab and allow workflows if GitHub asks
5. Run **Deploy GitHub Pages**, or push a new commit

Expected site address:

```text
https://sergiodipraha-maker.github.io/powerball-analyzer/
```

## Current project status

- [x] Responsive website
- [x] 7-line generator
- [x] Core Pool logic
- [x] Coverage wheel
- [x] Random baseline generator
- [x] Browser walk-forward backtest
- [x] Data validation
- [x] GitHub Pages workflow
- [x] Scheduled update framework
- [ ] Connect a confirmed official historical-results feed
- [ ] Populate and audit the complete historical database

## Independence notice

Powerball is a registered lottery game. This project is independent and is not
affiliated with or endorsed by Powerball, MUSL, Allwyn or The National Lottery.
